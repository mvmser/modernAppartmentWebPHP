<?php
    session_name('WebAppartment');
    session_start();
?>  
  