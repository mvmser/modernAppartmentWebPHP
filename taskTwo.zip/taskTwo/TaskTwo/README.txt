--------|URL|--------

http://web.fcet.staffs.ac.uk/s023212i/TaskTwo/index.php
http://web.fces.staffs.ac.uk/phpmyadmin

Thanks,
SERHIR Mohamed - s023212i

--------||--------