-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 03, 2018 at 01:57 PM
-- Server version: 5.5.8
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `s023212i`
--

-- --------------------------------------------------------

--
-- Table structure for table `collection`
--

CREATE TABLE IF NOT EXISTS `collection` (
  `itemID` int(4) NOT NULL,
  `prefix` varchar(2) NOT NULL,
  `description` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `URL` varchar(200) NOT NULL,
  `userID` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collection`
--

INSERT INTO `collection` (`itemID`, `prefix`, `description`, `URL`, `userID`) VALUES
(15, 'BD', 'Beautiful bedroom', 'https://www.nkrealtors.com/blog/wp-content/uploads/2016/09/luxury-apartment-in-kolkata-730x410.jpg', 1),
(16, 'OD', 'Modern facade', 'img/outdoor/modern-facade2.jpg', 1),
(17, 'OD', 'Another modern facade', 'img/outdoor/modern_facade3.jpg', 1),
(19, 'OD', 'Sunset modern outdoor', 'img/outdoor/sunset-modern-outdoor.jpg', 1),
(20, 'OD', 'Best exterior house ideas', 'img/outdoor/05-The-best-exterior-house-design-ideas-Architecture-Beast-01.jpg', 1),
(21, 'OD', 'Exterior design with pool', 'img/outdoor/LosOlivos_A4%20agents_page2_image1.jpg', 1),
(22, 'BA', 'Luxury bathroom', 'img/indoor/Harbour-Bathroom.jpg', 1),
(23, 'KT', 'White marbre kitchen', 'img/indoor/kitchen_Ratchford.jpg', 1),
(24, 'BD', 'Modern bedroom in nature', 'img/indoor/modern-bedroom.jpg', 1),
(25, 'LR', 'Modern wood living room', 'img/indoor/modern-living-room.jpg', 1),
(26, 'IN', 'Beautiful indoor space', 'http://cdn.home-designing.com/wp-content/uploads/2011/06/outdoor-indoor-living-space.jpg', 1),
(27, 'IN', 'Indoor garden', 'https://www.hostelgarden.net/wp-content/uploads/2014/12/large-indoor-garden-design-for-house.jpg', 1),
(38, 'LR', 'Big sobre living room ', 'https://www.sadecor.co.za/wp-content/uploads/wordpress/2017/05/Poliform%E2%80%99s-new-Mondrian-Sofa-delights-00.jpg-2.jpg', 2),
(39, 'LR', 'Modern Fusion ', 'https://www.thespruce.com/thmb/2vH0KWYdWKK-mBfYmNSTqrbO2QQ=/960x0/filters:no_upscale():max_bytes(150000):strip_icc():format(webp)/Living-room-with-modern-furniture-58a0a38c3df78c4758c97e39.jpg', 2),
(40, 'OD', 'Las vegas home', 'https://www.luxuryhomesoflasvegas.com/WP/wp-content/uploads/2018/04/The-Ridges-home-21-Meadowhawk-Ln-01.jpg', 2),
(41, 'OD', 'Blue sky in los angeles', 'http://elementreedrafting.com.au/wp-content/uploads/2015/05/What-makes-a-home-a-Luxury-Home.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `UserID` int(11) NOT NULL,
  `LoginName` varchar(50) CHARACTER SET utf8 NOT NULL,
  `LoginPassword` varchar(200) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `LoginName`, `LoginPassword`) VALUES
(1, 'momo', '$2y$10$YzRmw6xNgBllaQ3mkgyA5O20Bjw7ICAVA2mblsblf/mUoNno3Ma.u'),
(2, 'ines', '$2y$10$rKHkE049XHTR6C2D2w9r4.pcUtMoZH1rRyVB64rADhkvXHpbDN9qm'),
(3, 'test', '$2y$10$CiZjaX6vYlbFzq/hPe0OxOXojKRLZ/q3N3YrsQLBCGpxcIWF.b6.K');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `collection`
--
ALTER TABLE `collection`
  ADD PRIMARY KEY (`itemID`),
  ADD UNIQUE KEY `ID` (`itemID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `UserID` (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `collection`
--
ALTER TABLE `collection`
  MODIFY `itemID` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `collection`
--
ALTER TABLE `collection`
  ADD CONSTRAINT `collection_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
